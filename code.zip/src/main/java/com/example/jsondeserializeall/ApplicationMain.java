package com.example.jsondeserializeall;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

// json includes (manjula)
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ApplicationMain {
    public static void main(String[] args) throws IOException {
        String jsonReader = Files.readString(Path.of("C:\\Users\\came2\\OneDrive - Georgian College\\Documents\\Year 2\\Sem 1\\Advanced Java\\Week 9\\Quiz\\JSON-Deserialize-All\\src\\main\\java\\com\\example\\jsondeserializeall\\employees.json"));

        ObjectMapper objectMapper = new ObjectMapper();

        JsonNode TeamMembers = objectMapper.readTree(jsonReader).get("TeamMembers");
        for (JsonNode TeamUser : TeamMembers)
        {
            JsonNode FullName = TeamUser.get("full_name");
            System.out.println(FullName.asText());
        }

        System.out.println("OLEG KHRISNAH ABISHEK KUMAR JAMES BOND RUSHIKESH KUMAR PATEL SINGHDEEP SINGH JASPREET SINGH ISHAN KUMAR");
    }
}
