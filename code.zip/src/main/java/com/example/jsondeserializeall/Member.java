package com.example.jsondeserializeall;

public class Member {
    private String id;
    private String position;
    private String first_name;
    private String last_name;
    private String full_name;
    private String code;
    private String location;
    private String contact;
    private String email;

    // Getter for full_name to access preferred full name
    public String getFullName() {
        return full_name;
    }
}
