package com.example.jsondeserializeall;

import java.util.List;

public class Group {
    public List<Member> TeamMembers;
}
