module com.example.jsondeserializeall {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.fasterxml.jackson.databind;


    opens com.example.jsondeserializeall to javafx.fxml;
    exports com.example.jsondeserializeall;
}